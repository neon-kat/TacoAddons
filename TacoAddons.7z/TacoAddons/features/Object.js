import PogObject from "PogData";

// credits to endless for fucking up his one job

export const pogObject = new PogObject("TacoAddons", {
    amountSold: 0,
    fastestPre4: 99,
    fastestWeirdos: 99,
    fastestCreeper: 99,
    fastestWater: 99,
    fastestBlaze: 99,
    fastestIce: 99

    
},"../../../TacoAddons.json");

export default pogObject
