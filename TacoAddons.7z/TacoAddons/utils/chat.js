export function chat(args) {
    return ChatLib.chat("§8[§b§ltaco§f§8] §f" + args);
}

export default { chat }
